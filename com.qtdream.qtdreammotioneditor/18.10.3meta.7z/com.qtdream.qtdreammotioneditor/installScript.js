﻿// 这个脚本是安装萌梦动作编辑器使用的
function Component( )
{
}

Component.prototype.createOperations = function ( )
{
    // 调用默认的实现
    component.createOperations( );
    switch ( systemInfo.productType )
    {
    case "windows":
        component.addOperation( "CreateShortcut",
                                "@TargetDir@/bin/launcher.exe",
                                "@StartMenuDir@/萌梦动作编辑器.lnk",
                                "workingDirectory=@TargetDir@",
                                "description=打开萌梦动作编辑器" );
        component.addOperation( "CreateShortcut",
                                "@TargetDir@/bin/launcher.exe",
                                "@DesktopDir@/萌梦动作编辑器.lnk",
                                "workingDirectory=@TargetDir@",
                                "workingDirectory=@TargetDir@",
                                "description=打开萌梦动作编辑器" );
        break;
    }
}
